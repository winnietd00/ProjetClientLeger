<?php
//define sert a creer des variables (convention en Maj).

define ("NAMEBDD" ,  "ppe");
define ("HOST" ,  "localhost");
define ("ROOT" ,  "root");
define ("MDPBDD" ,  "");

?>