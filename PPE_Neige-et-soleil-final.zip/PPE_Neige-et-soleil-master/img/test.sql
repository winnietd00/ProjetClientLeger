 	insert into client (idClient ,nomClient ,prenomClient ,telClient ,mailClient) 
    VALUES (null, 'Ghaoui', 'Aghiles', '0689457851', 'aghiles.ghaoui30@gmail.com');
    
    
    insert into reservation (idResa ,DateD ,DateF ,numH ,idClient ) 
    VALUES (null, '2021-02-12', '2021-02-16', '1', '3');
    
    insert into users(	id_u,firstName,lastName	)
    VALUES (NULL, 'Aghiles', 'Ghaoui');